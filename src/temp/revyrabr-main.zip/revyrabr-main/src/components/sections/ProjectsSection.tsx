import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { ExternalLink, Heart, Users, Star } from "lucide-react";

const ProjectsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const projects = [
    {
      title: "CuidaBem",
      category: "Saúde & Cuidados",
      description:
        "Aplicativo completo para cuidadoras de idosos. Gestão de rotinas, medicamentos, relatórios e comunicação com familiares.",
      users: "Em breve",
      rating: "5.0",
      status: "Em Desenvolvimento",
      gradient: "from-primary/20 to-accent/20",
      icon: Heart,
    },
  ];

  return (
    <section
      ref={ref}
      id="projetos"
      className="relative py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-secondary/30 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block font-orbitron text-sm text-primary mb-4 tracking-widest uppercase">
            Portfólio
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mb-6">
            Nossos <span className="text-gradient">Projetos</span>
          </h2>
          <p className="font-inter text-lg text-muted-foreground max-w-2xl mx-auto">
            Cada projeto é uma experiência única, desenvolvida com tecnologia de ponta
            e pensada para escalar como um produto digital.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="flex justify-center">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ y: -10 }}
              className="group relative max-w-md w-full"
            >
              <div className="glass-card rounded-2xl overflow-hidden h-full border border-border/50 hover:border-primary/50 transition-all duration-500">
                {/* Card Header with Gradient */}
                <div
                  className={`relative h-48 bg-gradient-to-br ${project.gradient} flex items-center justify-center overflow-hidden`}
                >
                  <project.icon className="w-20 h-20 text-foreground/20 group-hover:text-primary/40 transition-colors duration-500 group-hover:scale-110" />
                  
                  {/* Status Badge */}
                  <div className="absolute top-4 right-4">
                    <span className="px-3 py-1 rounded-full text-xs font-orbitron font-semibold bg-primary/20 text-primary border border-primary/30">
                      {project.status}
                    </span>
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      whileHover={{ scale: 1.1 }}
                      className="w-14 h-14 rounded-full bg-primary flex items-center justify-center cursor-pointer neon-glow"
                    >
                      <ExternalLink className="w-6 h-6 text-primary-foreground" />
                    </motion.div>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-6">
                  <span className="font-inter text-xs text-primary uppercase tracking-wider">
                    {project.category}
                  </span>
                  <h3 className="font-orbitron text-xl font-bold mt-2 mb-3 text-foreground group-hover:text-gradient transition-all">
                    {project.title}
                  </h3>
                  <p className="font-inter text-sm text-muted-foreground mb-4">
                    {project.description}
                  </p>

                  {/* Stats */}
                  <div className="flex items-center gap-4 pt-4 border-t border-border/50">
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span className="font-inter text-sm text-muted-foreground">
                        {project.users}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Star className="w-4 h-4 text-accent fill-accent" />
                      <span className="font-inter text-sm text-muted-foreground">
                        {project.rating}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Coming Soon Note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12 font-inter text-muted-foreground"
        >
          Mais projetos em breve. Estamos trabalhando em novas soluções incríveis!
        </motion.p>
      </div>
    </section>
  );
};

export default ProjectsSection;
