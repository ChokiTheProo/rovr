import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { 
  Cpu, 
  Cloud, 
  Database, 
  Shield, 
  Zap, 
  GitBranch,
  Layers,
  Workflow
} from "lucide-react";

const TechSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const technologies = [
    { icon: Cpu, name: "Unity & Unreal", description: "Engines AAA" },
    { icon: Cloud, name: "Cloud Native", description: "AWS & GCP" },
    { icon: Database, name: "Real-time DB", description: "Firebase & Supabase" },
    { icon: Shield, name: "Anti-Cheat", description: "Segurança robusta" },
    { icon: Zap, name: "Low Latency", description: "< 50ms response" },
    { icon: GitBranch, name: "CI/CD", description: "Deploy contínuo" },
  ];

  const process = [
    { step: "01", title: "Conceito", description: "Ideação e validação de mercado" },
    { step: "02", title: "Prototipagem", description: "MVP funcional em semanas" },
    { step: "03", title: "Desenvolvimento", description: "Iteração ágil com feedback" },
    { step: "04", title: "Lançamento", description: "Go-to-market estratégico" },
  ];

  return (
    <section
      ref={ref}
      id="tecnologia"
      className="relative py-32 overflow-hidden"
    >
      <div className="container mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="inline-block font-orbitron text-sm text-primary mb-4 tracking-widest uppercase">
            Stack & Processo
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mb-6">
            Tecnologia de <span className="text-gradient">Ponta</span>
          </h2>
          <p className="font-inter text-lg text-muted-foreground max-w-2xl mx-auto">
            Utilizamos as melhores ferramentas e metodologias do mercado
            para entregar jogos de alta qualidade.
          </p>
        </motion.div>

        {/* Tech Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-24"
        >
          {technologies.map((tech, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: 0.1 * index }}
              whileHover={{ y: -5, scale: 1.05 }}
              className="glass-card p-6 rounded-xl text-center group hover:border-primary/50 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 group-hover:shadow-[0_0_20px_hsl(var(--primary)/0.3)] transition-all">
                <tech.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-orbitron text-sm font-semibold text-foreground mb-1">
                {tech.name}
              </h3>
              <p className="font-inter text-xs text-muted-foreground">
                {tech.description}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* Process Timeline */}
        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent hidden lg:block" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                className="relative"
              >
                <div className="glass-card p-8 rounded-2xl text-center relative z-10 h-full group hover:border-primary/50 transition-all duration-300">
                  {/* Step Number */}
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/30 mb-6 group-hover:border-primary group-hover:shadow-[0_0_30px_hsl(var(--primary)/0.4)] transition-all">
                    <span className="font-orbitron text-xl font-bold text-primary">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="font-orbitron text-lg font-bold text-foreground mb-3">
                    {item.title}
                  </h3>
                  <p className="font-inter text-sm text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechSection;
