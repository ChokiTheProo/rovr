import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { TrendingUp, Repeat, BarChart3, Rocket } from "lucide-react";

const MicroSaaSSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const benefits = [
    {
      icon: TrendingUp,
      title: "Crescimento Exponencial",
      description:
        "Arquitetura projetada para escalar de centenas a milhões de usuários sem refatoração.",
      stat: "10x",
      statLabel: "Crescimento médio",
    },
    {
      icon: Repeat,
      title: "Receita Recorrente",
      description:
        "Modelos de monetização que geram receita previsível e sustentável mês após mês.",
      stat: "MRR",
      statLabel: "Monthly Revenue",
    },
    {
      icon: BarChart3,
      title: "Métricas em Tempo Real",
      description:
        "Dashboard completo com KPIs de engajamento, retenção e monetização.",
      stat: "24/7",
      statLabel: "Monitoramento",
    },
    {
      icon: Rocket,
      title: "Automação Total",
      description:
        "Desde atualizações de conteúdo até campanhas de marketing, tudo automatizado.",
      stat: "90%",
      statLabel: "Processos automáticos",
    },
  ];

  return (
    <section
      ref={ref}
      id="micro-saas"
      className="relative py-32 overflow-hidden"
    >
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 via-background to-background" />
      
      {/* Decorative Elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-primary/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-accent/5 rounded-full blur-[120px]" />

      <div className="container mx-auto px-6 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="inline-block font-orbitron text-sm text-primary mb-4 tracking-widest uppercase">
            Nossa Filosofia
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mb-6">
            Visão <span className="text-gradient">Micro SaaS</span>
          </h2>
          <p className="font-inter text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Cada jogo da Revyra é tratado como um produto digital independente.
            Aplicamos metodologias de SaaS para criar games que não apenas entretêm,
            mas também geram valor de negócio mensurável e escalável.
          </p>
        </motion.div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ scale: 1.02 }}
              className="glass-card rounded-2xl p-8 group hover:border-primary/50 transition-all duration-300"
            >
              <div className="flex items-start gap-6">
                {/* Icon */}
                <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 group-hover:shadow-[0_0_25px_hsl(var(--primary)/0.3)] transition-all">
                  <benefit.icon className="w-7 h-7 text-primary" />
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3 className="font-orbitron text-lg font-bold text-foreground mb-2">
                    {benefit.title}
                  </h3>
                  <p className="font-inter text-sm text-muted-foreground mb-4 leading-relaxed">
                    {benefit.description}
                  </p>

                  {/* Stat */}
                  <div className="flex items-baseline gap-2">
                    <span className="font-orbitron text-2xl font-bold text-gradient">
                      {benefit.stat}
                    </span>
                    <span className="font-inter text-xs text-muted-foreground uppercase tracking-wider">
                      {benefit.statLabel}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom Quote */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <blockquote className="font-inter text-xl md:text-2xl text-muted-foreground italic max-w-3xl mx-auto">
            "Não criamos apenas jogos.{" "}
            <span className="text-foreground not-italic font-medium">
              Criamos produtos digitais
            </span>{" "}
            que crescem, evoluem e geram valor continuamente."
          </blockquote>
          <p className="font-orbitron text-sm text-primary mt-4 tracking-widest">
            — EQUIPE REVYRA
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default MicroSaaSSection;
