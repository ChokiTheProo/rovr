import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Zap, Target, TrendingUp, Users } from "lucide-react";

const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Zap,
      title: "Inovação Contínua",
      description:
        "Exploramos novas mecânicas e tecnologias para criar experiências únicas.",
    },
    {
      icon: Target,
      title: "Foco em Resultados",
      description:
        "Cada jogo é projetado com métricas claras de engajamento e monetização.",
    },
    {
      icon: TrendingUp,
      title: "Crescimento Escalável",
      description:
        "Arquitetura pensada para suportar milhões de usuários simultâneos.",
    },
    {
      icon: Users,
      title: "Experiência do Usuário",
      description:
        "Design centrado no jogador para máxima retenção e satisfação.",
    },
  ];

  return (
    <section
      ref={ref}
      id="sobre"
      className="relative py-32 overflow-hidden"
    >
      {/* Background Accent */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <span className="inline-block font-orbitron text-sm text-primary mb-4 tracking-widest uppercase">
              Sobre Nós
            </span>
            <h2 className="font-orbitron text-4xl md:text-5xl font-bold mb-6 leading-tight">
              Somos a{" "}
              <span className="text-gradient">Revyra</span>
            </h2>
            <p className="font-inter text-lg text-muted-foreground mb-6 leading-relaxed">
              A Revyra é um estúdio de desenvolvimento de jogos com DNA de startup. 
              Combinamos a paixão por games com estratégias de negócios digitais 
              para criar produtos que encantam e geram receita recorrente.
            </p>
            <p className="font-inter text-muted-foreground leading-relaxed">
              Nosso diferencial está na abordagem <strong className="text-foreground">Micro SaaS</strong>: 
              cada jogo é um produto independente, automatizado e escalável. 
              Da concepção à monetização, pensamos em cada detalhe para maximizar 
              o valor entregue aos jogadores e aos nossos parceiros.
            </p>
          </motion.div>

          {/* Right Content - Feature Cards */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="grid grid-cols-2 gap-4"
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="glass-card p-6 rounded-xl group hover:border-primary/50 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-orbitron text-sm font-semibold mb-2 text-foreground">
                  {feature.title}
                </h3>
                <p className="font-inter text-xs text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
