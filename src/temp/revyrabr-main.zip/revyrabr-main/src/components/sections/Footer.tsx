import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Gamepad2 } from "lucide-react";

const Footer = () => {

  const footerLinks = [
    {
      title: "Empresa",
      links: [
        { label: "Sobre", href: "/em-desenvolvimento/sobre" },
        { label: "Carreiras", href: "/em-desenvolvimento/carreiras" },
      ],
    },
    {
      title: "Recursos",
      links: [
        { label: "Documentação", href: "/documentacao" },
        { label: "API", href: "/em-desenvolvimento/api" },
        { label: "Suporte", href: "/em-desenvolvimento/suporte" },
      ],
    },
    {
      title: "Legal",
      links: [
        { label: "Privacidade", href: "/privacidade" },
        { label: "Termos", href: "/termos" },
        { label: "Cookies", href: "/cookies" },
        { label: "Licenças", href: "/em-desenvolvimento/licencas" },
      ],
    },
  ];

  return (
    <footer className="relative pt-20 pb-10 border-t border-border/50">
      {/* Gradient Line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <Link to="/" className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/30">
                  <Gamepad2 className="w-5 h-5 text-primary" />
                </div>
                <span className="font-orbitron text-2xl font-bold text-foreground">
                  REV<span className="text-primary">YRA</span>
                </span>
              </Link>
              <p className="font-inter text-muted-foreground max-w-xs leading-relaxed">
                Criamos jogos inteligentes que escalam como negócios. 
                Inovação, automação e experiências que encantam.
              </p>
            </motion.div>
          </div>

          {/* Links Columns */}
          {footerLinks.map((column, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
            >
              <h3 className="font-orbitron text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">
                {column.title}
              </h3>
              <ul className="space-y-3">
                {column.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link
                      to={link.href}
                      className="font-inter text-sm text-muted-foreground hover:text-primary transition-colors duration-200"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="pt-8 border-t border-border/30 flex flex-col md:flex-row justify-between items-center gap-4"
        >
          <p className="font-inter text-sm text-muted-foreground">
            © {new Date().getFullYear()} Revyra. Todos os direitos reservados.
          </p>
          <p className="font-inter text-sm text-muted-foreground">
            Feito com <span className="text-primary">♥</span> para gamers
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
