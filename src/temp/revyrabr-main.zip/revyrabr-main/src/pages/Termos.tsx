import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/sections/Footer";

const Termos = () => {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-8">
              Termos de <span className="text-gradient">Uso</span>
            </h1>
            
            <div className="glass-card rounded-2xl p-8 space-y-8">
              <div>
                <p className="font-inter text-muted-foreground mb-6">
                  Última atualização: {new Date().toLocaleDateString('pt-BR')}
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  1. Aceitação dos Termos
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Ao acessar e usar os serviços da Revyra, você concorda com estes termos 
                  de uso. Se você não concordar com qualquer parte destes termos, não 
                  deverá usar nossos serviços.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  2. Descrição dos Serviços
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  A Revyra oferece serviços de desenvolvimento de aplicativos e jogos 
                  Micro SaaS. Nos reservamos o direito de modificar, suspender ou 
                  descontinuar qualquer serviço a qualquer momento.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  3. Propriedade Intelectual
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Todo o conteúdo, design, código e propriedade intelectual apresentados 
                  neste site são de propriedade da Revyra ou licenciados para uso. É 
                  proibida a reprodução sem autorização prévia.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  4. Uso Aceitável
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Você concorda em não usar nossos serviços para qualquer finalidade 
                  ilegal ou não autorizada. Você não deve tentar obter acesso não 
                  autorizado aos nossos sistemas ou interferir em seu funcionamento.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  5. Limitação de Responsabilidade
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  A Revyra não será responsável por quaisquer danos indiretos, 
                  incidentais ou consequenciais decorrentes do uso ou incapacidade 
                  de usar nossos serviços.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  6. Alterações nos Termos
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Reservamo-nos o direito de modificar estes termos a qualquer momento. 
                  Alterações significativas serão comunicadas através de nosso site ou 
                  por e-mail.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  7. Lei Aplicável
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Estes termos serão regidos e interpretados de acordo com as leis 
                  do Brasil. Qualquer disputa será resolvida nos tribunais competentes.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default Termos;
