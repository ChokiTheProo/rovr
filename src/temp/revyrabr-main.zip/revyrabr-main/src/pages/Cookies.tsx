import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/sections/Footer";

const Cookies = () => {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-8">
              Política de <span className="text-gradient">Cookies</span>
            </h1>
            
            <div className="glass-card rounded-2xl p-8 space-y-8">
              <div>
                <p className="font-inter text-muted-foreground mb-6">
                  Última atualização: {new Date().toLocaleDateString('pt-BR')}
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  1. O que são Cookies?
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Cookies são pequenos arquivos de texto armazenados em seu dispositivo 
                  quando você visita um site. Eles são amplamente utilizados para fazer 
                  os sites funcionarem de forma mais eficiente e fornecer informações 
                  aos proprietários do site.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  2. Como Usamos Cookies
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed mb-4">
                  A Revyra utiliza cookies para:
                </p>
                <ul className="list-disc list-inside font-inter text-muted-foreground space-y-2">
                  <li>Garantir o funcionamento adequado do site</li>
                  <li>Lembrar suas preferências e configurações</li>
                  <li>Analisar como você usa nosso site para melhorá-lo</li>
                  <li>Personalizar sua experiência de navegação</li>
                </ul>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  3. Tipos de Cookies que Usamos
                </h2>
                <div className="space-y-4">
                  <div className="p-4 bg-secondary/30 rounded-lg">
                    <h3 className="font-orbitron text-sm font-semibold text-primary mb-2">
                      Cookies Essenciais
                    </h3>
                    <p className="font-inter text-sm text-muted-foreground">
                      Necessários para o funcionamento básico do site. Não podem ser desativados.
                    </p>
                  </div>
                  <div className="p-4 bg-secondary/30 rounded-lg">
                    <h3 className="font-orbitron text-sm font-semibold text-primary mb-2">
                      Cookies de Análise
                    </h3>
                    <p className="font-inter text-sm text-muted-foreground">
                      Nos ajudam a entender como os visitantes interagem com o site.
                    </p>
                  </div>
                  <div className="p-4 bg-secondary/30 rounded-lg">
                    <h3 className="font-orbitron text-sm font-semibold text-primary mb-2">
                      Cookies de Preferências
                    </h3>
                    <p className="font-inter text-sm text-muted-foreground">
                      Lembram suas escolhas e preferências para melhorar sua experiência.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  4. Gerenciar Cookies
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Você pode controlar e/ou excluir cookies conforme desejar. A maioria 
                  dos navegadores permite que você gerencie suas preferências de cookies. 
                  No entanto, desativar cookies pode afetar a funcionalidade do site.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  5. Contato
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Se você tiver dúvidas sobre nossa política de cookies, entre em 
                  contato conosco através do formulário de contato em nosso site.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default Cookies;
