import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/sections/Footer";

const Privacidade = () => {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-8">
              Política de <span className="text-gradient">Privacidade</span>
            </h1>
            
            <div className="glass-card rounded-2xl p-8 space-y-8">
              <div>
                <p className="font-inter text-muted-foreground mb-6">
                  Última atualização: {new Date().toLocaleDateString('pt-BR')}
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  1. Informações que Coletamos
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  A Revyra coleta informações que você nos fornece diretamente, como nome, 
                  e-mail e mensagens enviadas através do formulário de contato. Também podemos 
                  coletar informações automaticamente, como dados de navegação e cookies.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  2. Como Usamos suas Informações
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Utilizamos suas informações para responder às suas solicitações, melhorar 
                  nossos serviços, enviar comunicações relevantes (com seu consentimento) e 
                  garantir a segurança de nossos sistemas.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  3. Compartilhamento de Dados
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Não vendemos suas informações pessoais. Podemos compartilhar dados com 
                  prestadores de serviços que nos ajudam a operar nosso negócio, sempre 
                  sob acordos de confidencialidade.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  4. Seus Direitos
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Você tem o direito de acessar, corrigir ou excluir suas informações 
                  pessoais. Para exercer esses direitos, entre em contato conosco através 
                  do formulário de contato em nosso site.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  5. Segurança
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Implementamos medidas de segurança técnicas e organizacionais para 
                  proteger suas informações contra acesso não autorizado, alteração, 
                  divulgação ou destruição.
                </p>
              </div>

              <div>
                <h2 className="font-orbitron text-xl font-semibold mb-4 text-foreground">
                  6. Contato
                </h2>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  Se você tiver dúvidas sobre esta política de privacidade, entre em 
                  contato conosco através do formulário de contato em nosso site.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default Privacidade;
