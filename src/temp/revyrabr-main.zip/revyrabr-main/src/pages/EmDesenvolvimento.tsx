import { motion } from "framer-motion";
import { useParams, Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/sections/Footer";
import { Construction, ArrowLeft } from "lucide-react";
import { RevyraButton } from "@/components/ui/RevyraButton";

const EmDesenvolvimento = () => {
  const { page } = useParams();
  
  const pageNames: Record<string, string> = {
    sobre: "Sobre",
    carreiras: "Carreiras",
    blog: "Blog",
    imprensa: "Imprensa",
    api: "API",
    comunidade: "Comunidade",
    suporte: "Suporte",
    licencas: "Licenças",
  };

  const pageName = page ? pageNames[page] || page : "Esta página";

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-32 pb-20 min-h-[70vh] flex items-center">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl mx-auto text-center"
          >
            {/* Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="w-24 h-24 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-8 border border-primary/30"
            >
              <Construction className="w-12 h-12 text-primary" />
            </motion.div>

            {/* Title */}
            <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-6">
              <span className="text-gradient">{pageName}</span>
            </h1>

            {/* Description */}
            <p className="font-inter text-xl text-muted-foreground mb-8 leading-relaxed">
              Esta página está em desenvolvimento. Estamos trabalhando para 
              trazer o melhor conteúdo para você em breve!
            </p>

            {/* Back Button */}
            <Link to="/">
              <RevyraButton variant="outline" size="lg">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar para Home
              </RevyraButton>
            </Link>

            {/* Progress Animation */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-16"
            >
              <p className="font-inter text-sm text-muted-foreground mb-4">
                Progresso do desenvolvimento
              </p>
              <div className="w-full max-w-xs mx-auto h-2 bg-secondary rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                  initial={{ width: "0%" }}
                  animate={{ width: "35%" }}
                  transition={{ duration: 1, delay: 0.6 }}
                />
              </div>
              <p className="font-inter text-xs text-muted-foreground mt-2">
                35% concluído
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default EmDesenvolvimento;
