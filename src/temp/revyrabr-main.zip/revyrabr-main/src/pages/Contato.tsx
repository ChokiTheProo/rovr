import { motion } from "framer-motion";
import { Sparkles, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import ContactForm from "@/components/ContactForm";
import { Helmet } from "react-helmet-async";

const Contato = () => {
  return (
    <>
      <Helmet>
        <title>Fale Conosco | Revyra</title>
        <meta name="description" content="Entre em contato com a Revyra. Estamos prontos para transformar sua ideia em realidade." />
      </Helmet>
      
      <div className="min-h-screen bg-background relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 hero-gradient opacity-50" />
        <div className="absolute inset-0 grid-bg opacity-20" />
        
        {/* Floating Orbs */}
        <motion.div
          className="absolute top-1/4 left-1/4 w-48 h-48 bg-primary/20 rounded-full blur-[80px]"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-accent/15 rounded-full blur-[100px]"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        <div className="container mx-auto px-6 relative z-10 py-12">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Link 
              to="/" 
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="font-inter text-sm">Voltar ao início</span>
            </Link>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-16 items-center max-w-6xl mx-auto min-h-[calc(100vh-200px)]">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
            >
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full glass-card border border-primary/30">
                <Sparkles className="w-4 h-4 text-primary" />
                <span className="font-inter text-sm text-muted-foreground">
                  Vamos criar algo incrível juntos
                </span>
              </div>

              {/* Main Heading */}
              <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Pronto para{" "}
                <span className="text-gradient glow-text">transformar</span>
                <br />
                sua ideia em realidade?
              </h1>

              {/* Subtitle */}
              <p className="font-inter text-lg text-muted-foreground mb-8 leading-relaxed">
                Seja você um empreendedor com uma visão inovadora ou uma empresa 
                buscando expandir no mercado digital, a Revyra está pronta para 
                tornar seu projeto realidade.
              </p>

              {/* Trust Badges */}
              <div className="flex flex-wrap gap-6 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="font-inter text-sm">Resposta em 24h</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="font-inter text-sm">Consultoria gratuita</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-neon-pink" />
                  <span className="font-inter text-sm">NDA disponível</span>
                </div>
              </div>
            </motion.div>

            {/* Right Content - Contact Form */}
            <ContactForm />
          </div>
        </div>
      </div>
    </>
  );
};

export default Contato;
