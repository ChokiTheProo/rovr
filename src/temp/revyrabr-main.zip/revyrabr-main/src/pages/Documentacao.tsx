import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/sections/Footer";
import { Construction, FileText, Book, Code, Rocket } from "lucide-react";

const Documentacao = () => {
  const sections = [
    {
      icon: Book,
      title: "Guia de Início Rápido",
      description: "Aprenda os conceitos básicos e comece a usar nossos produtos.",
      status: "Em breve",
    },
    {
      icon: Code,
      title: "API Reference",
      description: "Documentação técnica completa das nossas APIs e SDKs.",
      status: "Em breve",
    },
    {
      icon: FileText,
      title: "Tutoriais",
      description: "Guias passo a passo para implementações comuns.",
      status: "Em breve",
    },
    {
      icon: Rocket,
      title: "Melhores Práticas",
      description: "Dicas e recomendações para otimizar sua experiência.",
      status: "Em breve",
    },
  ];

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-8">
              <span className="text-gradient">Documentação</span>
            </h1>
            
            {/* In Development Banner */}
            <div className="glass-card rounded-2xl p-8 mb-12 border border-primary/30">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Construction className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="font-orbitron text-xl font-semibold text-foreground">
                    Em Desenvolvimento
                  </h2>
                  <p className="font-inter text-muted-foreground">
                    Estamos trabalhando para trazer a melhor documentação para você.
                  </p>
                </div>
              </div>
              <p className="font-inter text-muted-foreground leading-relaxed">
                Nossa documentação completa está sendo preparada com carinho. Em breve, 
                você terá acesso a guias detalhados, tutoriais e referências técnicas 
                para aproveitar ao máximo nossos produtos e serviços.
              </p>
            </div>

            {/* Documentation Sections Preview */}
            <div className="grid md:grid-cols-2 gap-6">
              {sections.map((section, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="glass-card rounded-xl p-6 group hover:border-primary/50 transition-all duration-300"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                      <section.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-orbitron text-sm font-semibold text-foreground">
                          {section.title}
                        </h3>
                        <span className="px-2 py-0.5 rounded-full text-xs font-inter bg-muted text-muted-foreground">
                          {section.status}
                        </span>
                      </div>
                      <p className="font-inter text-sm text-muted-foreground">
                        {section.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Newsletter Signup */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-12 text-center"
            >
              <p className="font-inter text-muted-foreground">
                Quer ser notificado quando a documentação estiver disponível?{" "}
                <a href="/#contato" className="text-primary hover:underline">
                  Entre em contato
                </a>{" "}
                e avisaremos você!
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default Documentacao;
